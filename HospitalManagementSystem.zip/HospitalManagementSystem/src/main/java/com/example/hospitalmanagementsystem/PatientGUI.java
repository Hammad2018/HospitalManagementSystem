package com.example.hospitalmanagementsystem;

import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.sql.SQLException;
import java.util.List;

public class PatientGUI {

    private final PatientDAO patientDAO;
    private final DoctorDAO doctorDAO;

    public PatientGUI() throws SQLException {
        patientDAO = new PatientDAO();
        doctorDAO = new DoctorDAO();
    }

    public void setupUI(GridPane root) {
        VBox vbox = new VBox(10);

        TextField patientNameField = new TextField();
        patientNameField.setPromptText("Patient Name");

        Button viewProfileButton = new Button("View Profile");
        viewProfileButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                if (patientName.isEmpty()) {
                    showAlert("Please enter a patient name.");
                    return;
                }
                Patient patient = patientDAO.viewPatientProfile(patientName);
                if (patient != null) {
                    showPatientProfile(patient);
                } else {
                    showAlert("Patient not found.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while fetching the patient profile.");
            }
        });

        Button viewAppointmentsButton = new Button("View Appointments");
        viewAppointmentsButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                if (patientName.isEmpty()) {
                    showAlert("Please enter a patient name.");
                    return;
                }
                List<Appointment> appointments = patientDAO.viewAppointments(patientName);
                if (!appointments.isEmpty()) {
                    showAppointments(appointments);
                } else {
                    showAlert("No appointments found for the patient.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while fetching the appointments.");
            }
        });

        Button viewMedicalRecordButton = new Button("View Medical Record");
        viewMedicalRecordButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                if (patientName.isEmpty()) {
                    showAlert("Please enter a patient name.");
                    return;
                }
                MedicalRecord medicalRecord = patientDAO.viewMedicalRecord(patientName);
                if (medicalRecord != null) {
                    showMedicalRecord(medicalRecord);
                } else {
                    showAlert("Medical record not found for the patient.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while fetching the medical record.");
            }
        });

        Label statusLabel = new Label();

        vbox.getChildren().addAll(
                new Label("Patient Interface"),
                patientNameField,
                viewProfileButton,
                viewAppointmentsButton,
                viewMedicalRecordButton,
                statusLabel
        );

        root.add(vbox, 0, 0);
    }

    private void showPatientProfile(Patient patient) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Patient Profile");
        alert.setHeaderText("Patient Details");
        alert.setContentText(
                "ID: " + patient.getId() + "\n" +
                        "Name: " + patient.getName() + "\n" +
                        "Address: " + patient.getAddress() + "\n" +
                        "Phone Number: " + patient.getPhoneNumber() + "\n" +
                        "Medical History: " + patient.getMedicalHistory() + "\n" +
                        "Ward Number: " + patient.getWardNumber()
        );
        alert.showAndWait();
    }

    private void showAppointments(List<Appointment> appointments) {
        StringBuilder content = new StringBuilder();
        for (Appointment appointment : appointments) {
            content.append("ID: ").append(appointment.getId()).append("\n")
                    .append("Patient Name: ").append(appointment.getPatientName()).append("\n")
                    .append("Date: ").append(appointment.getDateTime().toLocalDate()).append("\n")
                    .append("Time: ").append(appointment.getDateTime().toLocalTime()).append("\n")
                    .append("Doctor Name: ").append(appointment.getDoctorName()).append("\n\n");
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Appointments");
        alert.setHeaderText("Appointment Details");
        alert.setContentText(content.toString());
        alert.showAndWait();
    }


    private void showMedicalRecord(MedicalRecord medicalRecord) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Medical Record");
        alert.setHeaderText("Medical Record Details");
        alert.setContentText(
                "ID: " + medicalRecord.getId() + "\n" +
                        "Patient Name: " + medicalRecord.getPatientName() + "\n" +
                        "Diagnosis: " + medicalRecord.getDiagnosis() + "\n" +
                        "Prescription: " + medicalRecord.getPrescription() + "\n" +
                        "Treatment: " + medicalRecord.getTreatment()
        );
        alert.showAndWait();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

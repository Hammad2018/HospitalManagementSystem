package com.example.hospitalmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO {
    private final Connection connection;

    public DoctorDAO() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException("Error connecting to the database", e);
        }
    }

    public Patient viewPatientProfile(String patientName) throws SQLException {
        String query = "SELECT * FROM patients WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String name = resultSet.getString("name");
                    String address = resultSet.getString("address");
                    String phoneNumber = resultSet.getString("phone_number");
                    String medicalHistory = resultSet.getString("medical_history");
                    int wardNumber = resultSet.getInt("ward_number");

                    return new Patient(id, name, address, phoneNumber, medicalHistory, wardNumber);
                } else {
                    return null; // Patient not found
                }
            }
        }
    }

    public void inputDiagnosis(String patientName, String diagnosis) throws SQLException {
        String query = "UPDATE medical_records SET diagnosis = ? WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, diagnosis);
            preparedStatement.setString(2, patientName);
            preparedStatement.executeUpdate();
        }
    }

    public void inputPrescription(String patientName, String prescription) throws SQLException {
        String query = "UPDATE medical_records SET prescription = ? WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, prescription);
            preparedStatement.setString(2, patientName);
            preparedStatement.executeUpdate();
        }
    }

    public void inputTreatment(String patientName, String treatment) throws SQLException {
        String query = "UPDATE medical_records SET treatment = ? WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, treatment);
            preparedStatement.setString(2, patientName);
            preparedStatement.executeUpdate();
        }
    }

    public ObservableList<Patient> getAllPatients() throws SQLException {
        List<Patient> patients = new ArrayList<>();
        String query = "SELECT * FROM patients";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String address = resultSet.getString("address");
                String phoneNumber = resultSet.getString("phone_number");
                String medicalHistory = resultSet.getString("medical_history");
                int wardNumber = resultSet.getInt("ward_number");

                Patient patient = new Patient(id, name, address, phoneNumber, medicalHistory, wardNumber);
                patients.add(patient);
            }
        }
        return FXCollections.observableArrayList(patients);
    }

    public ObservableList<Department> getAllDepartments() throws SQLException {
        List<Department> departments = new ArrayList<>();
        String query = "SELECT * FROM departments";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");

                Department department = new Department(id, name);
                departments.add(department);
            }
        }
        return FXCollections.observableArrayList(departments);
    }

    public ObservableList<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String query = "SELECT * FROM appointments";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String patientName = resultSet.getString("patient_name");
                String doctorName = resultSet.getString("doctor_name");
                LocalDateTime dateTime = resultSet.getTimestamp("date_time").toLocalDateTime();

                Appointment appointment = new Appointment(id, patientName, dateTime, doctorName);
                appointments.add(appointment);
            }
        }
        return FXCollections.observableArrayList(appointments);
    }
}

package com.example.hospitalmanagementsystem;

import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NurseDAO {
    private final Connection connection;

    public NurseDAO() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Method to record vital signs for a patient
    public void recordVitalSigns(String patientName, String vitalSigns) throws SQLException {
        if (isPatientExists(patientName)) {
            String query = "UPDATE medical_records SET vital_signs = ? WHERE patient_name = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, vitalSigns);
                preparedStatement.setString(2, patientName);
                preparedStatement.executeUpdate();
                showAlert("Vital signs recorded successfully.");
            }
        } else {
            showAlert("Patient does not exist.");
        }
    }

    // Method to update patient progress
    public void updatePatientProgress(String patientName, String progress) throws SQLException {
        String query = "UPDATE medical_records SET progress = CONCAT_WS('\n', COALESCE(progress, ''), ?) WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, progress);
            preparedStatement.setString(2, patientName);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Patient progress updated successfully.");
            } else {
                showAlert("Patient does not exist.");
            }
        }
    }

    // Method to update diagnosis and prescription
    public void updateDiagnosisAndPrescription(String patientName, String diagnosis, String prescription) throws SQLException {
        String query = "UPDATE medical_records SET diagnosis = ?, prescription = ? WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, diagnosis);
            preparedStatement.setString(2, prescription);
            preparedStatement.setString(3, patientName);
            preparedStatement.executeUpdate();
        }
    }

    // Method to check if a patient exists in the medical records table
    private boolean isPatientExists(String patientName) throws SQLException {
        String query = "SELECT 1 FROM medical_records WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    // Method to add a new patient to the medical records table if not already exists
    public void addNewPatient(String patientName) throws SQLException {
        if (!isPatientExists(patientName)) {
            String insertQuery = "INSERT INTO medical_records (patient_name) VALUES (?)";
            try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                insertStatement.setString(1, patientName);
                insertStatement.executeUpdate();
            }
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

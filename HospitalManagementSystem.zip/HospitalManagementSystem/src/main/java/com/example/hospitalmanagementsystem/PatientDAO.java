package com.example.hospitalmanagementsystem;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {
    private final Connection connection;

    public PatientDAO() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Patient viewPatientProfile(String patientName) throws SQLException {
        String query = "SELECT * FROM patients WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String address = resultSet.getString("address");
                    String phoneNumber = resultSet.getString("phone_number");
                    String medicalHistory = resultSet.getString("medical_history");
                    int wardNumber = resultSet.getInt("ward_number");

                    return new Patient(id, patientName, address, phoneNumber, medicalHistory, wardNumber);
                } else {
                    return null; // Patient not found
                }
            }
        }
    }

    public List<Appointment> viewAppointments(String patientName) throws SQLException {
        String query = "SELECT * FROM appointments WHERE patient_name = ?";
        List<Appointment> appointments = new ArrayList<>();
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    Timestamp dateTime = resultSet.getTimestamp("date_time");
                    String doctorName = resultSet.getString("doctor_name");

                    appointments.add(new Appointment(id, patientName, dateTime.toLocalDateTime(), doctorName));
                }
            }
        }
        return appointments;
    }

    public MedicalRecord viewMedicalRecord(String patientName) throws SQLException {
        String query = "SELECT * FROM medical_records WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String diagnosis = resultSet.getString("diagnosis");
                    String prescription = resultSet.getString("prescription");
                    String treatment = resultSet.getString("treatment");

                    return new MedicalRecord(id, patientName, diagnosis, prescription, treatment);
                } else {
                    return null; // Medical record not found
                }
            }
        }
    }

    public void addAppointment(String patientName, String doctorName, Timestamp appointmentTime, String department) throws SQLException {
        String query = "INSERT INTO appointments (patient_name, doctor_name, date_time, department) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, doctorName);
            preparedStatement.setTimestamp(3, appointmentTime);
            preparedStatement.setString(4, department);
            preparedStatement.executeUpdate();
        }
    }
}

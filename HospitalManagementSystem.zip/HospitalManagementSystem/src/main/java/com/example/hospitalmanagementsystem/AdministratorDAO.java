package com.example.hospitalmanagementsystem;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.example.hospitalmanagementsystem.DatabaseConnection.getConnection;

public class AdministratorDAO {
    private final Connection connection;

    public AdministratorDAO() {
        try {
            connection = getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void addPatient(String name, String address, String phoneNumber, String medicalHistory, String wardNumber) throws SQLException {
        String query = "INSERT INTO patients (name, address, phone_number, medical_history, ward_number) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, address);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setString(4, medicalHistory);
            preparedStatement.setString(5, wardNumber);
            preparedStatement.executeUpdate();

            // Insert a corresponding entry into medical_records table
            insertMedicalRecord(name);
        }
    }

    private void insertMedicalRecord(String patientName) throws SQLException {
        String query = "INSERT INTO medical_records (patient_name) VALUES (?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.executeUpdate();
        }
    }


    // Remove a patient record from the database using the patient name
    public void removePatientByName(String name) throws SQLException {
        String query = "DELETE FROM patients WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.executeUpdate();
        }

        // Also delete the corresponding medical record
        deleteMedicalRecord(name);
    }

    private void deleteMedicalRecord(String patientName) throws SQLException {
        String query = "DELETE FROM medical_records WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.executeUpdate();
        }
    }

    // Retrieve all patient records from the database
    public List<Patient> getAllPatients() throws SQLException {
        List<Patient> patients = new ArrayList<>();
        String query = "SELECT * FROM patients";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String address = resultSet.getString("address");
                String phoneNumber = resultSet.getString("phone_number");
                String medicalHistory = resultSet.getString("medical_history");
                int wardNumber = resultSet.getInt("ward_number");
                patients.add(new Patient(id, name, address, phoneNumber, medicalHistory, wardNumber));
            }
        }
        return patients;
    }

    // Methods for staff management
    public void addStaff(String name, String role, String phoneNumber, String address) throws SQLException {
        String query = "INSERT INTO staff (name, role, phone_number, address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, role);
            preparedStatement.setString(3, phoneNumber);
            preparedStatement.setString(4, address);
            preparedStatement.executeUpdate();
        }
    }

    // Remove a staff record from the database using the staff name
    public void removeStaffByName(String name) throws SQLException {
        if (!isStaffExists(name)) {
            showAlert("Staff member does not exist.");
            return; // Exit the method if staff does not exist
        }

        String query = "DELETE FROM staff WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showAlert("Staff removed successfully.");
            } else {
                showAlert("Error occurred while removing staff.");
            }
        }
    }


    // Method to check if a staff member exists in the staff table
    private boolean isStaffExists(String name) throws SQLException {
        String query = "SELECT 1 FROM staff WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    public List<Staff> getAllStaff() throws SQLException {
        List<Staff> staffList = new ArrayList<>();
        String query = "SELECT * FROM staff";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String role = resultSet.getString("role");
                String phoneNumber = resultSet.getString("phone_number");
                String address = resultSet.getString("address");
                staffList.add(new Staff(id, name, role, phoneNumber, address));
            }
        }
        return staffList;
    }

    // Methods for department management
    public void addDepartment(String name, String description) throws SQLException {
        String query = "INSERT INTO departments (name, description) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, description);
            preparedStatement.executeUpdate();
        }
    }

    // Remove a department record from the database using the department name
    public void removeDepartmentByName(String name) throws SQLException {
        String query = "DELETE FROM departments WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, name);
            preparedStatement.executeUpdate();
        }
    }

    public List<Department> getAllDepartments() throws SQLException {
        List<Department> departmentList = new ArrayList<>();
        String query = "SELECT * FROM departments";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                String description = resultSet.getString("description");
                departmentList.add(new Department(id, name));
            }
        }
        return departmentList;
    }

    public boolean isDepartmentExists(String departmentName) throws SQLException {
        String query = "SELECT 1 FROM departments WHERE name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, departmentName);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();
            }
        }
    }

    // Add a room to the database
    public void addRoom(String roomNumber, String type, String departmentName) throws SQLException {
        String query = "INSERT INTO rooms (room_number, type, department_name) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, roomNumber);
            preparedStatement.setString(2, type);
            preparedStatement.setString(3, departmentName);
            preparedStatement.executeUpdate();
        }
    }

    // Remove a room record from the database using the room number
    public void removeRoomByNumber(String roomNumber) throws SQLException {
        String query = "DELETE FROM rooms WHERE room_number = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, roomNumber);
            preparedStatement.executeUpdate();
        }
    }

    // Get all rooms from the database
    public List<Room> getAllRooms() throws SQLException {
        List<Room> roomList = new ArrayList<>();
        String query = "SELECT r.id, r.room_number, r.type, d.name AS department_name " +
                "FROM rooms r JOIN departments d ON r.department_name = d.name";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String roomNumber = resultSet.getString("room_number");
                String type = resultSet.getString("type");
                String departmentName = resultSet.getString("department_name");
                roomList.add(new Room(id, roomNumber, type, departmentName));
            }
        }
        return roomList;
    }

    // Handle adding a room
    public void handleAddRoom(String roomNumber, String type, String departmentName) {
        try {
            addRoom(roomNumber, type, departmentName);
            showAlert("Room added successfully.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("An error occurred while adding the room.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Add an appointment to the database
    public void addAppointment(String patientName, String doctorName, LocalDateTime appointmentDateTime) throws SQLException {
        String query = "INSERT INTO appointments (patient_name, doctor_name, date_time) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, doctorName);
            preparedStatement.setTimestamp(3, Timestamp.valueOf(appointmentDateTime));
            preparedStatement.executeUpdate();
        }
    }

    // Remove an appointment record from the database using the patient name
    public void removeAppointmentByPatientName(String patientName) throws SQLException {
        String query = "DELETE FROM appointments WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.executeUpdate();
        }
    }

    public ObservableList<Appointment> getAllAppointments() throws SQLException {
        List<Appointment> appointments = new ArrayList<>();
        String query = "SELECT * FROM appointments";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String patientName = resultSet.getString("patient_name");
                    String doctorName = resultSet.getString("doctor_name");
                    LocalDateTime dateTime = resultSet.getTimestamp("date_time").toLocalDateTime();

                    // Update the constructor call to match the new parameter order
                    Appointment appointment = new Appointment(id, patientName, dateTime, doctorName);
                    appointments.add(appointment);
                }
            }
        }
        return FXCollections.observableArrayList(appointments);
    }


    // Methods for billing management
    public void addBilling(String patientName, double amount, String status) throws SQLException {
        String query = "INSERT INTO bills (patient_name, amount, status) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, patientName);
            preparedStatement.setDouble(2, amount);
            preparedStatement.setString(3, status);
            preparedStatement.executeUpdate();
        }
    }

    // Update billing status based on patient name
    public void updateBillingStatusByPatientName(String patientName, String status) throws SQLException {
        String query = "UPDATE bills SET status = ? WHERE patient_name = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, status);
            preparedStatement.setString(2, patientName);
            preparedStatement.executeUpdate();
        }
    }

    public List<Bill> getAllBills() throws SQLException {
        List<Bill> billList = new ArrayList<>();
        String query = "SELECT * FROM bills";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String patientName = resultSet.getString("patient_name");
                double amount = resultSet.getDouble("amount");
                String status = resultSet.getString("status");
                billList.add(new Bill(id, patientName, amount, status));
            }
        }
        return billList;
    }

    // Handler for updating billing status
    public void handleUpdateBilling(TextField patientNameField, TextField statusField) {
        try {
            // Assuming patientNameField is a TextField for patient name
            String patientName = patientNameField.getText();
            String status = statusField.getText();

            System.out.println("Attempting to update billing status for patient: " + patientName + " with status: " + status);

            updateBillingStatusByPatientName(patientName, status);

            System.out.println("Billing status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

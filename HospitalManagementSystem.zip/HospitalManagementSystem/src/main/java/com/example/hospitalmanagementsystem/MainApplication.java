package com.example.hospitalmanagementsystem;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MainApplication extends Application {

    private Connection connection;

    @Override
    public void start(Stage primaryStage) {
        try {
            primaryStage.setTitle("Hospital Management System");

            // Create a VBox container for the main menu
            VBox vbox = new VBox();
            vbox.setAlignment(Pos.CENTER);
            vbox.setSpacing(20);
            vbox.setPadding(new Insets(50));
            vbox.getStyleClass().add("root"); // Apply root style

            // Add title label
            Label titleLabel = new Label("Hospital Management System");
            titleLabel.getStyleClass().add("label");
            titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

            // Create buttons
            Button patientBtn = createButton("Patient Panel");
            Button doctorBtn = createButton("Doctor Panel");
            Button nurseBtn = createButton("Nurse Panel");
            Button administratorBtn = createButton("Administrator Panel");
            Button reportBtn = createButton("Generate Reports");

            // Set button actions
            patientBtn.setOnAction(e -> openPanel("patient"));
            doctorBtn.setOnAction(e -> openPanel("doctor"));
            nurseBtn.setOnAction(e -> openPanel("nurse"));
            administratorBtn.setOnAction(e -> openPanel("administrator"));
            reportBtn.setOnAction(e -> generateReports());

            // Add components to VBox
            vbox.getChildren().addAll(titleLabel, patientBtn, doctorBtn, nurseBtn, administratorBtn, reportBtn);

            Scene scene = new Scene(vbox, 600, 400);

            // Add stylesheet
            String cssResourcePath = "/styles.css";
            String css = getClass().getResource(cssResourcePath).toExternalForm();
            scene.getStylesheets().add(css);

            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Button createButton(String text) {
        Button button = new Button(text);
        button.getStyleClass().add("panel-button");
        return button;
    }

    private void openPanel(String role) {
        Stage stage = new Stage();
        GridPane root = new GridPane();
        root.getStyleClass().add("root"); // Apply root style
        try {
            switch (role) {
                case "patient":
                    PatientGUI patientGUI = new PatientGUI();
                    patientGUI.setupUI(root);
                    stage.setTitle("Hospital Management System - Patient Panel");
                    break;
                case "doctor":
                    DoctorGUI doctorGUI = new DoctorGUI();
                    doctorGUI.setupUI(root);
                    stage.setTitle("Hospital Management System - Doctor Panel");
                    break;
                case "nurse":
                    NurseGUI nurseGUI = new NurseGUI();
                    nurseGUI.setupUI(root);
                    stage.setTitle("Hospital Management System - Nurse Panel");
                    break;
                case "administrator":
                    AdministratorGUI administratorGUI = new AdministratorGUI();
                    administratorGUI.setupUI(root);
                    stage.setTitle("Hospital Management System - Administrator Panel");
                    break;
                default:
                    System.err.println("Invalid user role.");
                    return;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            // Handle the SQLException here, such as displaying an error message
        }
        Scene scene = new Scene(root, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    private void generateReports() {
        try {
            List<HospitalPerformance> reports = getHospitalPerformanceReports();
            int totalPatients = getTotalPatients();
            int totalStaff = getTotalStaff();
            int totalDepartments = getTotalDepartments();
            int totalRooms = getTotalRooms();
            int totalAppointments = getTotalAppointments();
            double totalBillingAmount = getTotalBillingAmount();

            StringBuilder reportBuilder = new StringBuilder();
            reportBuilder.append("Hospital Performance Reports:\n\n");
            for (HospitalPerformance report : reports) {
                reportBuilder.append(report.toString()).append("\n");
            }
            reportBuilder.append("\nTotal Patients: ").append(totalPatients);
            reportBuilder.append("\nTotal Staff: ").append(totalStaff);
            reportBuilder.append("\nTotal Departments: ").append(totalDepartments);
            reportBuilder.append("\nTotal Rooms: ").append(totalRooms);
            reportBuilder.append("\nTotal Appointments: ").append(totalAppointments);
            reportBuilder.append("\nTotal Billing Amount: ").append(totalBillingAmount);

            showAlert("Hospital Reports", reportBuilder.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error", "Error occurred while generating reports.");
        }
    }

    private List<HospitalPerformance> getHospitalPerformanceReports() throws SQLException {
        List<HospitalPerformance> reports = new ArrayList<>();
        String query = "SELECT * FROM hospital_performance";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                String departmentName = resultSet.getString("department_name");
                int roomCount = resultSet.getInt("room_count");
                int staffCount = resultSet.getInt("staff_count");
                int patientCount = resultSet.getInt("patient_count");
                int appointmentCount = resultSet.getInt("appointment_count");
                double totalBilling = resultSet.getDouble("total_billing");
                reports.add(new HospitalPerformance(departmentName, roomCount, staffCount, patientCount, appointmentCount, totalBilling));
            }
        }
        return reports;
    }

    private int getTotalPatients() throws SQLException {
        String query = "SELECT COUNT(*) FROM patients";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        }
    }

    private int getTotalStaff() throws SQLException {
        String query = "SELECT COUNT(*) FROM staff";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        }
    }

    private int getTotalDepartments() throws SQLException {
        String query = "SELECT COUNT(*) FROM departments";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        }
    }

    private int getTotalRooms() throws SQLException {
        String query = "SELECT COUNT(*) FROM rooms";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        }
    }

    private int getTotalAppointments() throws SQLException {
        String query = "SELECT COUNT(*) FROM appointments";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            } else {
                return 0;
            }
        }
    }

    private double getTotalBillingAmount() throws SQLException {
        String query = "SELECT SUM(amount) FROM bills";
        try (Statement statement = getConnection().createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            if (resultSet.next()) {
                return resultSet.getDouble(1);
            } else {
                return 0.0;
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content); // corrected method name
        alert.showAndWait();
    }

    private Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            // Update the database URL, user, and password as per your setup
            String url = "jdbc:mysql://localhost:3306/hospital_management"; // corrected database name
            String user = "root";
            String password = "1234";
            connection = DriverManager.getConnection(url, user, password);
        }
        return connection;
    }

    public static void main(String[] args) {
        launch(args);
    }
}

package com.example.hospitalmanagementsystem;

import java.time.LocalDateTime;

public class Appointment {
    private int id;
    private String patientName;
    private LocalDateTime dateTime; // Updated data type
    private String doctorName;

    public Appointment(int id, String patientName, LocalDateTime dateTime, String doctorName) {
        this.id = id;
        this.patientName = patientName;
        this.dateTime = dateTime;
        this.doctorName = doctorName;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getPatientName() {
        return patientName;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public String getDoctorName() {
        return doctorName;
    }
}

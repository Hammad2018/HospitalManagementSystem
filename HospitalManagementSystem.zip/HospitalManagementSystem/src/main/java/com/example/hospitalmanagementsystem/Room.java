package com.example.hospitalmanagementsystem;

public class Room {
    private final int id;
    private final String roomNumber;
    private final String type;
    private final String departmentName;

    public Room(int id, String roomNumber, String type, String departmentName) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.type = type;
        this.departmentName = departmentName;
    }

    // Getters
    public int getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getType() { return type; }
    public String getDepartmentName() { return departmentName; }
}

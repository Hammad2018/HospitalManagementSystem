package com.example.hospitalmanagementsystem;

public class Bill {
    private int id;
    private String patientName; // Changed to String to match the table
    private double amount;
    private String status;

    public Bill(int id, String patientName, double amount, String status) {
        this.id = id;
        this.patientName = patientName;
        this.amount = amount;
        this.status = status;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPatientName() { // Corrected method name to match the field
        return patientName;
    }

    public void setPatientName(String patientName) { // Corrected method name to match the field
        this.patientName = patientName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

package com.example.hospitalmanagementsystem;

class HospitalPerformance {
    private String departmentName;
    private int roomCount;
    private int staffCount;
    private int patientCount;
    private int appointmentCount;
    private double totalBilling;

    // Constructor
    public HospitalPerformance(String departmentName, int roomCount, int staffCount, int patientCount, int appointmentCount, double totalBilling) {
        this.departmentName = departmentName;
        this.roomCount = roomCount;
        this.staffCount = staffCount;
        this.patientCount = patientCount;
        this.appointmentCount = appointmentCount;
        this.totalBilling = totalBilling;
    }

    // Getters
    public String getDepartmentName() {
        return departmentName;
    }

    public int getRoomCount() {
        return roomCount;
    }

    public int getStaffCount() {
        return staffCount;
    }

    public int getPatientCount() {
        return patientCount;
    }

    public int getAppointmentCount() {
        return appointmentCount;
    }

    public double getTotalBilling() {
        return totalBilling;
    }

    // Setters
    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public void setRoomCount(int roomCount) {
        this.roomCount = roomCount;
    }

    public void setStaffCount(int staffCount) {
        this.staffCount = staffCount;
    }

    public void setPatientCount(int patientCount) {
        this.patientCount = patientCount;
    }

    public void setAppointmentCount(int appointmentCount) {
        this.appointmentCount = appointmentCount;
    }

    public void setTotalBilling(double totalBilling) {
        this.totalBilling = totalBilling;
    }

    // toString method
    @Override
    public String toString() {
        return "Department: " + departmentName +
                ", Rooms: " + roomCount +
                ", Staff: " + staffCount +
                ", Patients: " + patientCount +
                ", Appointments: " + appointmentCount +
                ", Total Billing: " + totalBilling;
    }
}


package com.example.hospitalmanagementsystem;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class NurseGUI {

    private final NurseDAO nurseDAO;

    public NurseGUI() {
        nurseDAO = new NurseDAO();
    }

    public void setupUI(GridPane root) {
        VBox vbox = new VBox(10);

        TextField patientNameField = new TextField();
        patientNameField.setPromptText("Patient Name");

        TextArea vitalSignsArea = new TextArea();
        vitalSignsArea.setPromptText("Enter Vital Signs");

        Button recordVitalSignsButton = new Button("Record Vital Signs");
        recordVitalSignsButton.setOnAction(e -> {
            try {
                nurseDAO.recordVitalSigns(
                        patientNameField.getText(),
                        vitalSignsArea.getText()
                );
                vitalSignsArea.clear();
                // Optionally show success message
                System.out.println("Vital signs recorded successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                // Handle SQL Exception here
            }
        });

        TextArea progressArea = new TextArea();
        progressArea.setPromptText("Enter Patient Progress");

        Button updateProgressButton = new Button("Update Progress");
        updateProgressButton.setOnAction(e -> {
            try {
                nurseDAO.updatePatientProgress(
                        patientNameField.getText(),
                        progressArea.getText()
                );
                progressArea.clear();
                // Optionally show success message
                System.out.println("Patient progress updated successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                // Handle SQL Exception here
            }
        });

        // Additional components for updating diagnosis and prescription
        TextField diagnosisField = new TextField();
        diagnosisField.setPromptText("Enter Diagnosis");

        TextField prescriptionField = new TextField();
        prescriptionField.setPromptText("Enter Prescription");

        Button updateDiagnosisPrescriptionButton = new Button("Update Diagnosis & Prescription");
        updateDiagnosisPrescriptionButton.setOnAction(e -> {
            try {
                nurseDAO.updateDiagnosisAndPrescription(
                        patientNameField.getText(),
                        diagnosisField.getText(),
                        prescriptionField.getText()
                );
                diagnosisField.clear();
                prescriptionField.clear();
                // Optionally show success message
                System.out.println("Diagnosis and prescription updated successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                // Handle SQL Exception here
            }
        });

        Label statusLabel = new Label();

        vbox.getChildren().addAll(
                new Label("Nurse Interface"),
                patientNameField,
                vitalSignsArea,
                recordVitalSignsButton,
                progressArea,
                updateProgressButton,
                diagnosisField,
                prescriptionField,
                updateDiagnosisPrescriptionButton,
                statusLabel
        );

        root.add(vbox, 0, 0);
    }
}

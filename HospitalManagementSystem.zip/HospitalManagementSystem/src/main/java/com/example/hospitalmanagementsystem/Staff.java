package com.example.hospitalmanagementsystem;

public class Staff {
    private final int id;
    private final String name;
    private final String role;
    private final String phoneNumber;
    private final String address;

    public Staff(int id, String name, String role, String phoneNumber, String address) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    // Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress() { return address; }
}

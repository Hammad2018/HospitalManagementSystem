package com.example.hospitalmanagementsystem;

import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.sql.SQLException;

public class DoctorGUI {

    private final DoctorDAO doctorDAO;
    private final TableView<Patient> patientTableView;
    private final TableView<Department> departmentTableView;
    private final TableView<Appointment> appointmentTableView;

    public DoctorGUI() {
        doctorDAO = new DoctorDAO();
        patientTableView = new TableView<>();
        departmentTableView = new TableView<>();
        appointmentTableView = new TableView<>();
    }

    public void setupUI(GridPane root) {
        VBox vbox = new VBox(10);

        TextField patientNameField = new TextField();
        patientNameField.setPromptText("Patient Name");

        Button viewProfileButton = new Button("View Profile");
        viewProfileButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                Patient patient = doctorDAO.viewPatientProfile(patientName);
                if (patient != null) {
                    showPatientProfile(patient);
                } else {
                    showAlert("Patient not found.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while fetching the patient profile.");
            }
        });

        TextArea diagnosisArea = new TextArea();
        diagnosisArea.setPromptText("Enter Diagnosis");

        Button inputDiagnosisButton = new Button("Input Diagnosis");
        inputDiagnosisButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                String diagnosis = diagnosisArea.getText();
                doctorDAO.inputDiagnosis(patientName, diagnosis);
                diagnosisArea.clear();
                showAlert("Diagnosis input successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while inputting the diagnosis.");
            }
        });

        TextArea prescriptionArea = new TextArea();
        prescriptionArea.setPromptText("Enter Prescription");

        Button inputPrescriptionButton = new Button("Input Prescription");
        inputPrescriptionButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                String prescription = prescriptionArea.getText();
                doctorDAO.inputPrescription(patientName, prescription);
                prescriptionArea.clear();
                showAlert("Prescription input successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while inputting the prescription.");
            }
        });

        TextArea treatmentArea = new TextArea();
        treatmentArea.setPromptText("Enter Treatment");

        Button inputTreatmentButton = new Button("Input Treatment");
        inputTreatmentButton.setOnAction(e -> {
            try {
                String patientName = patientNameField.getText();
                String treatment = treatmentArea.getText();
                doctorDAO.inputTreatment(patientName, treatment);
                treatmentArea.clear();
                showAlert("Treatment input successfully.");
            } catch (SQLException ex) {
                ex.printStackTrace();
                showAlert("An error occurred while inputting the treatment.");
            }
        });

        // Patient Table
        configureTable(patientTableView, new String[]{"ID", "Name", "Address", "Phone Number", "Medical History"},
                new String[]{"id", "name", "address", "phoneNumber", "medicalHistory"});

        // Department Table
        configureTable(departmentTableView, new String[]{"ID", "Name"},
                new String[]{"id", "name"});

        // Appointment Table (remove "Treatment" column)
        configureTable(appointmentTableView, new String[]{"ID", "Patient Name", "Doctor Name", "Date/Time"},
                new String[]{"id", "patientName", "doctorName", "dateTime"});

        vbox.getChildren().addAll(
                new Label("Doctor Interface"),
                new HBox(new Label("Patient Name: "), patientNameField, viewProfileButton),
                new HBox(new Label("Diagnosis: "), diagnosisArea, inputDiagnosisButton),
                new HBox(new Label("Prescription: "), prescriptionArea, inputPrescriptionButton),
                new HBox(new Label("Treatment: "), treatmentArea, inputTreatmentButton),
                new Label("Patients"),
                patientTableView,
                new Label("Departments"),
                departmentTableView,
                new Label("Appointments"),
                appointmentTableView
        );

        root.add(vbox, 0, 0);

        // Populate initial data
        refreshTables();
    }

    private void showPatientProfile(Patient patient) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Patient Profile");
        alert.setHeaderText("Patient Details");
        alert.setContentText(
                "ID: " + patient.getId() + "\n" +
                        "Name: " + patient.getName() + "\n" +
                        "Address: " + patient.getAddress() + "\n" +
                        "Phone Number: " + patient.getPhoneNumber() + "\n" +
                        "Medical History: " + patient.getMedicalHistory()
        );
        alert.showAndWait();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private <T> void configureTable(TableView<T> tableView, String[] columnNames, String[] propertyNames) {
        for (int i = 0; i < columnNames.length; i++) {
            TableColumn<T, String> column = new TableColumn<>(columnNames[i]);
            column.setCellValueFactory(new PropertyValueFactory<>(propertyNames[i]));
            tableView.getColumns().add(column);
        }
    }

    private void refreshTables() {
        try {
            ObservableList<Patient> patients = doctorDAO.getAllPatients();
            patientTableView.setItems(patients);

            ObservableList<Department> departments = doctorDAO.getAllDepartments();
            departmentTableView.setItems(departments);

            ObservableList<Appointment> appointments = doctorDAO.getAllAppointments();
            appointmentTableView.setItems(appointments);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

package com.example.hospitalmanagementsystem;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class AdministratorGUI {

    private final AdministratorDAO administratorDAO;

    public AdministratorGUI() {
        administratorDAO = new AdministratorDAO();
    }

    public void setupUI(GridPane root) {
        root.setPadding(new Insets(10));
        root.setHgap(10);
        root.setVgap(20);

        // Patient Management
        Label patientLabel = new Label("Patient Management:");
        TextField patientNameField = createTextField("Name");
        TextField patientAddressField = createTextField("Address");
        TextField patientPhoneNumberField = createTextField("Phone Number");
        TextField patientMedicalHistoryField = createTextField("Medical History");
        TextField patientWardNumberField = createTextField("Ward Number");
        Button addPatientButton = createButton("Add Patient");
        Button removePatientButton = createButton("Remove Patient");

        // Staff Management
        Label staffLabel = new Label("Staff Management:");
        TextField staffNameField = createTextField("Name");
        TextField staffRoleField = createTextField("Role");
        TextField staffPhoneNumberField = createTextField("Phone Number");
        TextField staffAddressField = createTextField("Address");
        Button addStaffButton = createButton("Add Staff");
        Button removeStaffButton = createButton("Remove Staff");

        // Department Management
        Label departmentLabel = new Label("Department Management:");
        TextField departmentNameField = createTextField("Name");
        TextField departmentDescriptionField = createTextField("Description");
        Button addDepartmentButton = createButton("Add Department");
        Button removeDepartmentButton = createButton("Remove Department");

        // Room Management
        Label roomLabel = new Label("Room Management:");
        TextField roomNumberField = createTextField("Room Number");
        TextField roomTypeField = createTextField("Room Type");
        TextField roomDepartmentIdField = createTextField("Department Name");
        Button addRoomButton = createButton("Add Room");
        Button removeRoomButton = createButton("Remove Room");

        // Appointment Management
        Label appointmentLabel = new Label("Appointment Management:");
        TextField appointmentPatientNameField = createTextField("Patient Name");
        TextField appointmentDoctorNameField = createTextField("Doctor Name");
        DatePicker appointmentDatePicker = new DatePicker();
        appointmentDatePicker.setPromptText("Select Date");
        ComboBox<String> appointmentTimePicker = createTimePicker();
        Button addAppointmentButton = createButton("Add Appointment");
        Button removeAppointmentButton = createButton("Remove Appointment");

        // Billing Management
        Label billingLabel = new Label("Billing Management:");
        TextField billingPatientNameField = createTextField("Patient Name");
        TextField billingAmountField = createTextField("Amount");
        TextField billingStatusField = createTextField("Status");
        Button addBillingButton = createButton("Add Billing");
        Button updateBillingButton = createButton("Update Billing Status");
        Button removeBillingButton = createButton("Remove Billing");

        // Add components to grid
        int row = 0;
        root.add(patientLabel, 0, row);
        root.add(patientNameField, 1, row);
        root.add(patientAddressField, 2, row);
        root.add(patientPhoneNumberField, 3, row);
        root.add(patientMedicalHistoryField, 4, row);
        root.add(patientWardNumberField, 5, row);
        root.add(addPatientButton, 6, row);
        root.add(removePatientButton, 7, row++);
        root.add(new Label(""), 0, row++); // Spacing

        root.add(staffLabel, 0, row);
        root.add(staffNameField, 1, row);
        root.add(staffRoleField, 2, row);
        root.add(staffPhoneNumberField, 3, row);
        root.add(staffAddressField, 4, row);
        root.add(addStaffButton, 5, row);
        root.add(removeStaffButton, 6, row++);
        root.add(new Label(""), 0, row++); // Spacing

        root.add(departmentLabel, 0, row);
        root.add(departmentNameField, 1, row);
        root.add(departmentDescriptionField, 2, row);
        root.add(addDepartmentButton, 3, row);
        root.add(removeDepartmentButton, 4, row++);
        root.add(new Label(""), 0, row++); // Spacing

        root.add(roomLabel, 0, row);
        root.add(roomNumberField, 1, row);
        root.add(roomTypeField, 2, row);
        root.add(roomDepartmentIdField, 3, row);
        root.add(addRoomButton, 4, row);
        root.add(removeRoomButton, 5, row++);
        root.add(new Label(""), 0, row++); // Spacing

        root.add(appointmentLabel, 0, row);
        root.add(appointmentPatientNameField, 1, row);
        root.add(appointmentDoctorNameField, 2, row);
        root.add(appointmentDatePicker, 3, row);
        root.add(appointmentTimePicker, 4, row);
        root.add(addAppointmentButton, 5, row);
        root.add(removeAppointmentButton, 6, row++);
        root.add(new Label(""), 0, row++); // Spacing

        root.add(billingLabel, 0, row);
        root.add(billingPatientNameField, 1, row);
        root.add(billingAmountField, 2, row);
        root.add(billingStatusField, 3, row);
        root.add(addBillingButton, 4, row);
        root.add(updateBillingButton, 5, row++);
        root.add(new Label(""), 0, row++); // Spacing

        // Set button actions
        addPatientButton.setOnAction(event -> handleAddPatient(patientNameField, patientAddressField, patientPhoneNumberField, patientMedicalHistoryField, patientWardNumberField));
        removePatientButton.setOnAction(event -> handleRemovePatient(patientNameField));

        addStaffButton.setOnAction(event -> handleAddStaff(staffNameField, staffRoleField, staffPhoneNumberField, staffAddressField));
        removeStaffButton.setOnAction(event -> handleRemoveStaff(staffNameField));

        addDepartmentButton.setOnAction(event -> handleAddDepartment(departmentNameField, departmentDescriptionField));
        removeDepartmentButton.setOnAction(event -> handleRemoveDepartment(departmentNameField));

        addRoomButton.setOnAction(event -> handleAddRoom(roomNumberField, roomTypeField, roomDepartmentIdField));
        removeRoomButton.setOnAction(event -> handleRemoveRoom(roomNumberField));

        addAppointmentButton.setOnAction(event -> handleAddAppointment(appointmentPatientNameField, appointmentDoctorNameField, appointmentDatePicker, appointmentTimePicker));
        removeAppointmentButton.setOnAction(event -> handleRemoveAppointment(appointmentPatientNameField));

        addBillingButton.setOnAction(event -> handleAddBilling(billingPatientNameField, billingAmountField, billingStatusField));
        updateBillingButton.setOnAction(event -> handleUpdateBilling(billingPatientNameField, billingAmountField, billingStatusField));
    }

    private void clearTextFields(TextField... textFields) {
        for (TextField textField : textFields) {
            textField.clear();
        }
    }

    private void handleAddStaff(TextField nameField, TextField roleField, TextField phoneNumberField, TextField addressField) {
        try {
            administratorDAO.addStaff(nameField.getText(), roleField.getText(), phoneNumberField.getText(), addressField.getText());
            showAlert("Staff added successfully.");
            clearTextFields(nameField, roleField, phoneNumberField, addressField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding staff.");
        }
    }

    private void handleRemoveStaff(TextField nameField) {
        try {
            administratorDAO.removeStaffByName(nameField.getText());
            showAlert("Staff removed successfully.");
            clearTextFields(nameField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while removing staff.");
        }
    }

    private void handleAddDepartment(TextField nameField, TextField descriptionField) {
        try {
            administratorDAO.addDepartment(nameField.getText(), descriptionField.getText());
            showAlert("Department added successfully.");
            clearTextFields(nameField, descriptionField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding department.");
        }
    }

    private void handleRemoveDepartment(TextField nameField) {
        try {
            administratorDAO.removeDepartmentByName(nameField.getText());
            showAlert("Department removed successfully.");
            clearTextFields(nameField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while removing department.");
        }
    }

    private void handleAddRoom(TextField roomNumberField, TextField roomTypeField, TextField departmentNameField) {
        try {
            String departmentName = departmentNameField.getText();
            if (administratorDAO.isDepartmentExists(departmentName)) {
                administratorDAO.addRoom(roomNumberField.getText(), roomTypeField.getText(), departmentName);
                showAlert("Room added successfully.");
                clearTextFields(roomNumberField, roomTypeField, departmentNameField);
            } else {
                showAlert("Error: Department does not exist.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding room.");
        }
    }

    private void handleRemoveRoom(TextField roomNumberField) {
        try {
            administratorDAO.removeRoomByNumber(roomNumberField.getText());
            showAlert("Room removed successfully.");
            clearTextFields(roomNumberField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while removing room.");
        }
    }

    private void handleAddAppointment(TextField patientNameField, TextField doctorNameField, DatePicker appointmentDatePicker, ComboBox<String> appointmentTimePicker) {
        try {
            LocalDate date = appointmentDatePicker.getValue();
            String timeString = appointmentTimePicker.getValue();
            LocalTime time = LocalTime.parse(timeString);
            LocalDateTime dateTime = LocalDateTime.of(date, time);
            administratorDAO.addAppointment(patientNameField.getText(), doctorNameField.getText(), Timestamp.valueOf(dateTime).toLocalDateTime());
            showAlert("Appointment added successfully.");
            clearTextFields(patientNameField, doctorNameField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding appointment.");
        }
    }

    private void handleRemoveAppointment(TextField patientNameField) {
        try {
            administratorDAO.removeAppointmentByPatientName(patientNameField.getText());
            showAlert("Appointment removed successfully.");
            clearTextFields(patientNameField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while removing appointment.");
        }
    }

    private void handleAddBilling(TextField patientNameField, TextField amountField, TextField statusField) {
        try {
            String patientName = patientNameField.getText();
            double amount = Double.parseDouble(amountField.getText());
            String status = statusField.getText();
            administratorDAO.addBilling(patientName, amount, status);
            showAlert("Billing added successfully.");
            clearTextFields(patientNameField, amountField, statusField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding billing.");
        }
    }

    private void handleUpdateBilling(TextField patientNameField, TextField amountField, TextField billingStatusField) {
        try {
            String patientName = patientNameField.getText();
            String status = billingStatusField.getText(); // Corrected parameter to retrieve status
            administratorDAO.updateBillingStatusByPatientName(patientName, status);
            showAlert("Billing status updated successfully.");

            // Clear text fields after action is performed
            clearTextFields(patientNameField, amountField, billingStatusField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while updating billing status.");
        }
    }


    private TextField createTextField(String promptText) {
        TextField textField = new TextField();
        textField.setPromptText(promptText);
        return textField;
    }

    private Button createButton(String text) {
        Button button = new Button(text);
        button.setPrefWidth(160);
        return button;
    }

    private ComboBox<String> createTimePicker() {
        ComboBox<String> comboBox = new ComboBox<>();
        comboBox.setPromptText("Select Time");
        for (int hour = 0; hour < 24; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                comboBox.getItems().add(String.format("%02d:%02d", hour, minute));
            }
        }
        return comboBox;
    }

    private void handleAddPatient(TextField nameField, TextField addressField, TextField phoneNumberField, TextField medicalHistoryField, TextField wardNumberField) {
        try {
            administratorDAO.addPatient(nameField.getText(), addressField.getText(), phoneNumberField.getText(), medicalHistoryField.getText(), wardNumberField.getText());
            showAlert("Patient added successfully.");
            clearTextFields(nameField, addressField, phoneNumberField, addressField, medicalHistoryField, wardNumberField);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while adding patient.");
        }
    }

    private void handleRemovePatient(TextField nameField) {
        try {
            administratorDAO.removePatientByName(nameField.getText());
            showAlert("Patient removed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error occurred while removing patient.");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
